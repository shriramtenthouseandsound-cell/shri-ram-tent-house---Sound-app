SHRI RAM TENT HOUSE & SOUND — IONIC / ANDROID PROJECT

Yeh aapki maujooda billing app ko Ionic + Capacitor Android project mein wrap karta hai.
App ka existing bill layout aur features www/index.html mein rakhe gaye hain.

APK banane ke liye:
1. Computer par Node.js (LTS) aur Android Studio install karein.
2. Is folder ko extract karein.
3. Is folder mein terminal / command prompt kholein.
4. Commands chalayein:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
5. Android Studio mein Gradle sync hone dein.
6. Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
7. APK Android Studio ke app/build/outputs/apk/debug/ folder mein milegi.

NOTE:
- Yeh source project hai, compiled APK nahi.
- LocalStorage data har phone/browser mein alag rahega. Dono phones ke beech automatic sync abhi is package mein enabled nahi hai.
- Google Drive/Gmail backup ke liye secure Google sign-in integration alag se add karni hogi. Gmail password app mein kabhi na daalein.
